class PauseButton extends Button {
  constructor() {
  }

  draw() {
    if (super.onClickListner) this.update();
  }

  update() {
    this.spriteY = (this.spriteY + 1) % 2; // change button on click
  }
}
