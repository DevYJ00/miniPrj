class Context {
  constructor() {
    this.maincanvas = null; //Fruits Ninja Main Canvas 넘기기

   

  }
}

export default new Context(); //객체를 보낼때 x의 값만 보내주면
